package com.nocom.myapplication;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.safetynet.HarmfulAppsData;
import com.google.android.gms.safetynet.SafetyNet;
import com.google.android.gms.safetynet.SafetyNetApi;
import com.google.android.gms.safetynet.SafetyNetClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.scottyab.safetynet.SafetyNetHelper;
import com.scottyab.safetynet.SafetyNetResponse;
import com.scottyab.safetynet.Utils;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;



/*

        the goals of our app :
        SafetyNet Attestation API
        Learn how the SafetyNet Attestation API provides services for determining whether a device running your app satisfies Android compatibility tests.
        SafetyNet Safe Browsing API
        Learn how the SafetyNet Safe Browsing API provides services for determining whether a URL has been marked as a known threat by Google.
        SafetyNet reCAPTCHA API
        Learn how the SafetyNet reCAPTCHA API protects your app from malicious traffic.
        SafetyNet Verify Apps API
        Learn how the SafetyNet Verify Apps API protects devices against potentially harmful apps.



the reason for using Safety net:
The SafetyNet Attestation API helps you assess the security and compatibility of the Android environments in which your apps run
. You can use this API to analyze devices that have installed your app.






 the reason for using SafetyNet Safe Browsing API:
SafetyNet provides services for determining whether a URL has been marked as a known threat by Google.
Your app can use this API to determine whether a particular URL has been classified by Google as a known threat. Internally, SafetyNet implements a client for the Safe Browsing Network Protocol v4 developed by Google. Both the client code and the v4 network protocol were designed to preserve users' privacy and keep battery and bandwidth consumption to a minimum. Use this API to take full advantage of Google's Safe Browsing service on Android in the most resource-optimized way,
and without implementing its network protocol.
This document explains how to use SafetyNet to check a URL for known threats.
To use the Safe Browsing API, you must initialize the API by calling initSafeBrowsing() and waiting for it to complete.
The following code snippet provides an example:
Tasks.await(SafetyNet.getClient(this).initSafeBrowsing());



 the reason for using SafetyNet reCAPTCHA API:
The SafetyNet service includes a reCAPTCHA API that you can use to protect your app from malicious traffic.
reCAPTCHA is a free service that uses an advanced risk analysis engine to protect your app from spam and other abusive actions.
If the service suspects that the user interacting with your app might be a bot instead of a human,
 it serves a CAPTCHA that a human must solve before your app can continue executing.





the reason for choosing SafetyNet Verify Apps API:
The SafetyNet Verify Apps API allows your app to interact programmatically with the Verify Apps feature on a device,
 protecting the device against potentially harmful apps.
*/


public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {


// An activity is the entry point for interacting with the user. It represents a single screen with a user interface. For example
// , an email app might have one activity that shows a list of new emails,
// another activity to compose an email, and another activity for reading emails.
// Although the activities work together to form a cohesive user experience in the email app, each one is independent of the others.
// As such, a different app can start any one of these activities if the email app allows it.
// For example, a camera app can start the activity in the email app that composes new mail to allow the user to share a picture.




/*
that why we use app compactivity :
Base class for activities that use the support library action bar features.
You can add an ActionBar to your activity when running on API level 7 or higher
 by extending this class for your activity and setting the activity theme to Theme.AppCompat
 or a similar theme.
*/


/*
 the reason for using implements :


 In object-oriented programming, inheritance is when an object or class is based on another object
   class (class-based inheritance), using the same implementation. ... Still
 , inheritance is a commonly used mechanism for establishing subtype relationships.
  here we depend on Google api client

  the . (dot) after the Class (Google client ) is used to acsses two functions we work on
  when the connection is succefully , and listner to listen if the conncetion failed

*/



//1) start with defining the button sign in sha1
    // link to put shai to complete recording :   https://console.developers.google.com/apis/credentials/key?project=lllll-199317

    Button safebrowsingbutton;// number one to start with
    Button verifyappsbutton; // third one
    Button attestiationbutton; // forth one
    TextView ctc ;
    TextView basicintegrity;
    TextView safebrwosingtext;



    // here is object of a class GoogleApiclient
     /*
        we need to know what is object :
      Executable entity combining code and data
      Code is organised into methods
      Data is accessed via the methods

   mGoogleApiClient is our object of Class  GoogleApiClient

  so what is a Class :

  Template or factory for creating objects
  called "instances" of the class
  Has definitions of methods and data
  Supports inheritance from other classes
  hence "class hierarchy"

     */

    //thats why we got no error found in safe browsing :
    // I can see why the Transparency Report wording and Safe Browsing API responses appear to contradict one another.
    // The Transparency Report communicates the extent to which the provided site is bad; in this case,
    // the site is only "partially" bad ("Some pages on this site..."). The Safe Browsing API, however,
    // will only return a verdict when the provided URL is definitively bad;
    // i.e. we have determined that all URLs (including the root domain) are not unsafe for a user to access.
    String url = " http://www.ianfette.org/";
    private SafetyNetHelper safetyNetHelper;
    private GoogleApiClient mGoogleApiClient;
    TextView tvResult;
    // a variable holds safety net name
    private static final String TAG = "SafetyNetHelperSAMPLE";
    //  our api key we register for
    private static final String API_KEY = "AIzaSyBsNxqkmtoVtG4YDa3lB8kBXlEhMGKoOG4";
    // the key used for Recaptcha send as a paramter
    final String SiteKey = "6LeJVkoUAAAAAEpUe9sphAsT-5zAJnBM6NGPy_8W";
    // thats a website we test for safety net api

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        verifyappsbutton = (Button) findViewById(R.id.verify_safety_apps_button);
        safebrowsingbutton = (Button) findViewById(R.id.safe_browsing_button);
        safetyNetHelper = new SafetyNetHelper(API_KEY);
        attestiationbutton = findViewById(R.id.safety_net_button);
        ctc = (TextView) findViewById(R.id.ctc_attestiation);
        basicintegrity = (TextView)findViewById(R.id.basicIntegrity_attestiation);
        safebrwosingtext = (TextView)findViewById(R.id.result_safe_browsing);


        // safety net verify apps test :
        // here we use safety net helper libirary
        // we use ready mde libirary in our android apps so it can help us in some concepts
        // earlier we call an object from the libirary class we use it down and send it our api key whitch
        // is special for our app


        verifyappsbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //Determine whether app verification is enabled
                //The asynchronous isVerifyAppsEnabled() method allows your app to determine whether the user is enrolled in the Verify Apps feature.
                // This method returns a VerifyAppsUserResult object, which contains information regarding all actions that the user has taken related to the Verify Apps feature, including enabling it.

                // The following code snippet shows how to create the callback associated with this method:


                SafetyNet.getClient(getApplicationContext())
                        .isVerifyAppsEnabled()
                        .addOnCompleteListener(new OnCompleteListener<SafetyNetApi.VerifyAppsUserResponse>() {
                            @Override
                            public void onComplete(Task<SafetyNetApi.VerifyAppsUserResponse> task) {
                                if (task.isSuccessful()) {
                                    SafetyNetApi.VerifyAppsUserResponse result = task.getResult();
                                    if (result.isVerifyAppsEnabled()) {
                                        Log.d("MY_APP_TAG", "The Verify Apps feature is enabled.");
                                        //   Toast.makeText(getApplicationContext(),"The Verify Apps feature is enabled",Toast.LENGTH_SHORT).show();
                                    } else {
                                        Log.d("MY_APP_TAG", "The Verify Apps feature is disabled.");
                                        // Toast.makeText(getApplicationContext(),"The Verify Apps feature is disabled",Toast.LENGTH_SHORT).show();

                                    }
                                } else {
                                    Log.e("MY_APP_TAG", "A general error occurred.");
                                }
                            }
                        });


                //    Request enabling of app verification
                //   The asynchronous enableVerifyApps() method allows your app to invoke a dialog requesting that the user enable the Verify Apps feature.
                // This method returns a VerifyAppsUserResult object,
                // which contains information regarding all actions that the user has taken related to the Verify Apps feature,
                // including whether they've given consent to enable it.

                //     The following code snippet shows how to create the callback associated with this method:


                SafetyNet.getClient(getApplicationContext())
                        .enableVerifyApps()
                        .addOnCompleteListener(new OnCompleteListener<SafetyNetApi.VerifyAppsUserResponse>() {
                            @Override
                            public void onComplete(Task<SafetyNetApi.VerifyAppsUserResponse> task) {
                                if (task.isSuccessful()) {
                                    SafetyNetApi.VerifyAppsUserResponse result = task.getResult();
                                    if (result.isVerifyAppsEnabled()) {
                                        Log.d("MY_APP_TAG", "The user gave consent " +
                                                "to enable the Verify Apps feature.");
                                    } else {
                                        Log.d("MY_APP_TAG", "The user didn't give consent " +
                                                "to enable the Verify Apps feature.");
                                    }
                                } else {
                                    Log.e("MY_APP_TAG", "A general error occurred.");
                                }
                            }
                        });


                SafetyNetClient safetyNetClient = SafetyNet.getClient(getApplicationContext());

                safetyNetClient.listHarmfulApps()
                        .addOnCompleteListener(new OnCompleteListener<SafetyNetApi.HarmfulAppsResponse>() {
                            @Override

                            //Task<TResult>	Represents an asynchronous operation.
                            //Task is a class
                            public void onComplete(@NonNull Task<SafetyNetApi.HarmfulAppsResponse> task) {


                                if (task.isSuccessful()) {
                                    SafetyNetApi.HarmfulAppsResponse result = task.getResult();

                                    List<HarmfulAppsData> appList = result.getHarmfulAppsList();
                                    if (appList.isEmpty()) {
                                        Log.d("FragmentSafetyNet", "There are no known potentially harmful apps installed.");
                                        Toast.makeText(getApplicationContext(), "There are no known potentially harmful apps installed", Toast.LENGTH_SHORT).show();
                                    } else {

                                        Log.e("FragmentSafetyNet", "Potentially harmful apps are installed!");

                                        Toast.makeText(getApplicationContext(), "Potentially harmful apps are installed!", Toast.LENGTH_SHORT).show();


                                        for (HarmfulAppsData harmfulApp : appList) {
                                            Log.e("SafetyNet", "Information about a harmful app:");
                                            Log.e("SafetyNet", "  APK: " + harmfulApp.apkPackageName);
                                            Log.e("SafetyNet", "  SHA-256: " + harmfulApp.apkSha256);
                                            Log.e("SafetyNet", "  Category: " + harmfulApp.apkCategory);
                                        }
                                    }
                                } else {

                                    Toast.makeText(getApplicationContext(), "An error occured during the operation  ", Toast.LENGTH_SHORT).show();


                                }
                            }
                        })
                        .addOnSuccessListener(new OnSuccessListener<SafetyNetApi.HarmfulAppsResponse>() {
                            @Override
                            public void onSuccess(SafetyNetApi.HarmfulAppsResponse harmfulAppsResponse) {
                                Log.d("listHarmfulApps()", "Sucess! Received listHarmfulApps() result");
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Log.e("listHarmfulApps()", "Error on failure lisner lisner has an error : " + e.getMessage());
                            }
                        });

            }
        });




        // the first one to implement
        safebrowsingbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                // the asynctask is defined by three generic types params ,progress,result
                //

                final LoadThreatData loadThreatData = new LoadThreatData();


                loadThreatData.execute();

            }
        });


        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(SafetyNet.API)
                .addConnectionCallbacks(MainActivity.this)
                .addOnConnectionFailedListener(MainActivity.this)
                .build();

        mGoogleApiClient.connect();


        Log.d(TAG, "AndroidAPIKEY: " + Utils.getSigningKeyFingerprint(this) + ";" + getPackageName());


        //tvResult = (TextView) findViewById(R.id.result);



        attestiationbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                final SafetyNetHelper safetyNetHelper = new SafetyNetHelper("AIzaSyDsYqAB3nN9rLrqNC-SN0bA2MJfkrL7hGw");

                safetyNetHelper.requestTest(getApplicationContext(), new SafetyNetHelper.SafetyNetWrapperCallback() {
                    @Override
                    public void error(int errorCode, String msg) {
                        //handle and retry depending on errorCode
                        Log.e("moha", msg);
                        Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void success(boolean ctsProfileMatch, boolean basicIntegrity ) {

                        if (ctsProfileMatch) {
                            //profile of the device running your app matches the profile of a device that has passed Android compatibility testing.

                           // Toast.makeText(getApplicationContext(),"ctc:true",Toast.LENGTH_SHORT).show();
                            ctc.setText("ctc:true");
                            //handle fail, maybe warn user device is unsupported or in compromised state? (this is up to you!)

                        } if(basicIntegrity){

                           // Toast.makeText(getApplicationContext(),"basicIntegrity:true",Toast.LENGTH_SHORT).show();

                            basicintegrity.setText("basicIntegrity:true");
                            //then the device running your app likely wasn't tampered with, but the device has not necessarily passed Android compatibility testing.
                        }else {


                            Toast.makeText(getApplicationContext(),"the device is not supported  ",Toast.LENGTH_SHORT).show();
                        }


                    }


                });

            }
        });
    }






    /* private void showLoading(boolean show) {

         // i need help in syntax of this code  !!!!!!!!!!!!!!
         loading.setVisibility(show ? View.VISIBLE : View.GONE);
         if (show) {
             resultsContainer.setBackgroundColor(Color.TRANSPARENT);
             resultsContainer.setVisibility(View.GONE);
         }
     }
 */

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }


    // @SuppressLint("StaticFieldLeak")

    //AsyncTask enables proper and easy use of the UI thread.
    //This class allows you to perform background operations and publish results on the UI thread without having to manipulate threads and/or handlers.

    // The three types used by an asynchronous task are the following:

    // Params, the type of the parameters sent to the task upon execution.
    //       Progress, the type of the progress units published during the background computation.
    //     Result, the type of the result of the background computation.

    //  Not all types are always used by an asynchronous task. To mark a type as unused, simply use the type Void:

    //  private class MyTask extends AsyncTask<Void, Void, Void> { ... }



    /*



    When an asynchronous task is executed, the task goes through 4 steps:

onPreExecute(), invoked on the UI thread before the task is executed. This step is normally
 used to setup the task, for instance by showing a progress bar in the user interface.
doInBackground(Params...), invoked on the background thread immediately after onPreExecute() finishes executing.
 This step is used to perform background computation that can take a long time.
 The parameters of the asynchronous task are passed to this step.
  The result of the computation must be returned by this step and will be passed back to the last step.
  This step can also use publishProgress(Progress...) to publish one or more units of progress
  . These values are published on the UI thread, in the onProgressUpdate(Progress...) step.
onProgressUpdate(Progress...), invoked on the UI thread after a call to publishProgress(Progress...)
. The timing of the execution is undefined.
 This method is used to display any form of progress in the user interface while the background computation is still executing.
  For instance, it can be used to animate a progress bar or show logs in a text field.
onPostExecute(Result), invoked on the UI thread after the background computation finishes.
 The result of the background computation is passed to this step as a parameter.
    * */


    public class LoadThreatData extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            SafetyNet.getClient(getApplicationContext()).initSafeBrowsing();
            Log.d("Threats", "init");

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            //"go.trackmyclicks202.com";//"http://ianfette.org/"; //"http://malware.wicar.org/data/eicar.com";


            SafetyNet.getClient(getApplicationContext()).lookupUri(
                    url,
                    API_KEY,
                    SafeBrowsingThreat.TYPE_POTENTIALLY_HARMFUL_APPLICATION,
                    SafeBrowsingThreat.TYPE_SOCIAL_ENGINEERING)
                    .addOnSuccessListener(new OnSuccessListener<SafetyNetApi.SafeBrowsingResponse>() {
                        @Override
                        public void onSuccess(SafetyNetApi.SafeBrowsingResponse sbResponse) {
                            // Indicates communication with the service was successful.
                            // Identify any detected threats.
                            if (sbResponse.getDetectedThreats().isEmpty()) {
                                // No threats found.
                                Log.e("Threats", "no threats found");

                                safebrwosingtext.setText("no threats found ");

                                //always get in here
                            } else {
                                // Threats found!
                                Log.e("Threats", sbResponse.toString());

                                safebrwosingtext.setText(" threats found ");

                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // An error occurred while communicating with the service.
                            if (e instanceof ApiException) {
                                // An error with the Google Play Services API contains some
                                // additional details.
                                ApiException apiException = (ApiException) e;
                                Log.d(TAG, "Error : " + CommonStatusCodes
                                        .getStatusCodeString(apiException.getStatusCode()));


                                safebrwosingtext.setText("error1"+CommonStatusCodes.getStatusCodeString(apiException.getStatusCode()));

                                // Note: If the status code, apiException.getStatusCode(),
                                // is SafetyNetstatusCode.SAFE_BROWSING_API_NOT_INITIALIZED,
                                // you need to call initSafeBrowsing(). It means either you
                                // haven't called initSafeBrowsing() before or that it needs
                                // to be called again due to an internal error.
                            } else {
                                // A different, unknown type of error occurred.
                                Log.d(TAG, "Error: " + e.getMessage());


                                safebrwosingtext.setText("error1"+e.getMessage());

                            }
                        }
                    });

        }




    }

    /*

SafetyNet Attestation API result :

    If the value of ctsProfileMatch is true,
     then the profile of the device running your app matches the profile of a device that has passed Android compatibility testing.

   If the value of basicIntegrity is true, then the device running your app likely wasn't tampered with,
   but the device hasn't necessarily passed Android compatibility testing.



    * */
}
