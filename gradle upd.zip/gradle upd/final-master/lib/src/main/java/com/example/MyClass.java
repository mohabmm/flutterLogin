package com.example;

public class MyClass {
    public String getJoke() {
        return "This is totally a funny joke";
    }


}
