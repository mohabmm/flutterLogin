
package com.nocom.bakingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity {

    private static final String TAG = "DetailActivity";

    private  Boolean mTabletMode = false;


    Bundle bundle;
    public static final String SHARED_PREFS_KEY = "SHARED_PREFS_KEY";

    List<Ingrideint> listItems;
    ArrayList<? extends Steps> listItems2;

    Recipe currentrecipie;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detailactivity);
        Log.d(TAG, "onCreate: Started.");
        final Intent intentThatStartedThisActivity = getIntent();
        final Bundle b = this.getIntent().getExtras();
        if (b != null && intentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT)&&intentThatStartedThisActivity.hasExtra(Intent.EXTRA_REFERRER)) {
            listItems = new ArrayList<>();
            currentrecipie = b.getParcelable("Movie");
            listItems= b.getParcelableArrayList("Movie");
            listItems2=b.getParcelableArrayList("moha");
             bundle = new Bundle();
            bundle.putParcelableArrayList("edttext", (ArrayList<? extends Parcelable>) listItems);
            bundle.putParcelableArrayList("moha",  listItems2);
            String json = new Gson().toJson(listItems );
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(SHARED_PREFS_KEY, json).commit();

        }



        if (savedInstanceState == null) {


            if(findViewById(R.id.container3)!= null){
                mTabletMode = true;
                Toast.makeText(getApplicationContext(),"in tablet",Toast.LENGTH_SHORT).show();
                FragmentIngridientAndSteps detailFragment = new FragmentIngridientAndSteps();
                detailFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.container, detailFragment).commit();
            }

            else {


                mTabletMode=false;
                FragmentIngridientAndSteps detailFragment = new FragmentIngridientAndSteps();
                detailFragment.setArguments(bundle);
                getSupportFragmentManager().beginTransaction().replace(R.id.container, detailFragment).commit();
            }
        }


        else {


            listItems = savedInstanceState.getParcelableArrayList("someVarA");
            listItems2 = savedInstanceState.getParcelableArrayList("someVarB");



            if(findViewById(R.id.container3)!= null){
                mTabletMode = true;
                Toast.makeText(getApplicationContext(),"in tablet",Toast.LENGTH_SHORT).show();
                FragmentIngridientAndSteps detailFragment = new FragmentIngridientAndSteps();
                detailFragment.setArguments(bundle);
            }

            else {


                mTabletMode=false;
                FragmentIngridientAndSteps detailFragment = new FragmentIngridientAndSteps();
                detailFragment.setArguments(bundle);
            }

        }

    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("someVarA", (ArrayList<? extends Parcelable>) listItems);
        outState.putParcelableArrayList("someVarB",  listItems2);    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

    }

    public  boolean isTablet() {
        return mTabletMode;
    }


    public void replaceFragment() {
        final FragmentTransaction t = this.getSupportFragmentManager().beginTransaction();
        FragmentDetailedSteps newFragment = new FragmentDetailedSteps();
        newFragment.setArguments(bundle);
        t.add(R.id.container2, newFragment);
        t.addToBackStack(null);
        t.commit();

    }

}
