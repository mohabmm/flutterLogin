
package com.nocom.movie2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;

import java.util.ArrayList;

/**
 * Created by Moha on 9/29/2017.
 */


public class TrailerAdapter extends ArrayAdapter<Trailer> {

    /**
     * Constructs a new {@link TrailerAdapter}.
     ** @param context     of the app
     * @param trailers is the list of trailers, which is the data source of the adapter
     */
    public TrailerAdapter(Context context, ArrayList<Trailer> trailers) {
        super(context, 0, trailers);
    }

    /**
     * Returns a list item view that displays information about the earthquake at the given position
     * in the list of earthquakes.
     */

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if there is an existing list item view (called convertView) that we can reuse,
        // otherwise, if convertView is null, then inflate a new list item layout.
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.trailerlist, parent, false);
        }
        Trailer currentTrailer = getItem(position);
        ImageButton trailerViD = (ImageButton) listItemView.findViewById(R.id.vid);


        trailerViD.setImageResource(R.drawable.time);

        return listItemView;
    }


}