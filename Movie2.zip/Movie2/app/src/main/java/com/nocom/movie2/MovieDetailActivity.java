package com.nocom.movie2;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Looper;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.paolorotolo.expandableheightlistview.ExpandableHeightListView;
import com.squareup.picasso.Picasso;

import org.json.JSONException;

import java.util.ArrayList;

import data.MovieContract;
import data.MovieCursorAdapter;
import data.MoviesDBHelper;

import static data.MovieContract.BASE_CONTENT_URI;

public class MovieDetailActivity extends AppCompatActivity {
    static String key = "";
    static String rev = "";
    ImageView iamgt;
    TextView overvview;
    //Button btn  ;
    FloatingActionButton toggleButton ;
    TextView title;
    //ImageView iamge2;
    String gettingImageUrl;
    String TRAILER_WEBSITE;
    String REVIEW_WEBSITE;
    TextView releasedate;
    TextView rating;
    Cursor c ;
   // MovieCursorAdapter adapter ;
    TextView reviews;
    Movie currentMovie;
   // Button TrailerButton;
    MoviesDBHelper dbHelper;
    //TextView review ;
    Button button;
    MovieCursorAdapter movieCursorAdapter;
    private SQLiteDatabase mDb;
    private boolean isFavorite;
    private ReviewAdapter mAdapter;
    private TrailerAdapter tAdapter;
    public MovieDetailActivity() {
    }

    public MovieDetailActivity(String ncontent) {
        rev = ncontent;
    }

    public static String getKey() {
        return key;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_detail);
        //final ListView trailerListview = (ListView) findViewById(R.id.list);
        ExpandableHeightListView expandableListView = (ExpandableHeightListView) findViewById(R.id.list);
        ExpandableHeightListView expandableListViewT = (ExpandableHeightListView) findViewById(R.id.trailer);
        // Create a DB helper (this will create the DB if run for the first time)
        dbHelper = new MoviesDBHelper(this);///
        // btn = (Button)findViewById(R.id.btn);
        toggleButton=(FloatingActionButton) findViewById(R.id.button2);
        // Keep a reference to the mDb until paused or killed. Get a writable database
        // because you will be adding restaurant customers
        // mDb = dbHelper.getWritableDatabase();
        mAdapter = new ReviewAdapter(this, new ArrayList<Review>());
        tAdapter = new TrailerAdapter(this, new ArrayList<Trailer>());
        expandableListView.setAdapter(mAdapter);
        expandableListView.setExpanded(true);
        expandableListViewT.setAdapter(tAdapter);
        expandableListViewT.setExpanded(true);
        // button=(Button) findViewById(R.id.button);
        ActionBar actionBar = this.getSupportActionBar();

        // Set the action bar back button to look like an up button
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        //  button = (Button) findViewById(R.id.button2);
        setTitle(R.string.MovieDetail);
        // TrailerButton = (Button) findViewById(R.id.trailer);
        iamgt = (ImageView) findViewById(R.id.image);//image
        overvview = (TextView) findViewById(R.id.overview);
        //reviews = ((TextView) findViewById(R.id.review));
        //review=(TextView)findViewById(R.id.review);
        title = (TextView) findViewById(R.id.title);
        releasedate = (TextView) findViewById(R.id.releasedate);
        rating = (TextView) findViewById(R.id.rate);
        Bundle b = this.getIntent().getExtras();
        Intent intentThatStartedThisActivity = getIntent();
        if (b != null && intentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT) && intentThatStartedThisActivity.hasExtra(Intent.EXTRA_SHORTCUT_NAME) && intentThatStartedThisActivity.hasExtra(Intent.EXTRA_REFERRER) && intentThatStartedThisActivity.hasExtra(Intent.EXTRA_INSTALLER_PACKAGE_NAME)) {
            String textEntered = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEXT);
            String textentered2 = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_SHORTCUT_NAME);
            String textentered3 = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_REFERRER);
            String textentered4 = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_INSTALLER_PACKAGE_NAME);
            currentMovie = b.getParcelable("Movie");
            overvview.setText(textEntered);
            title.setText(textentered2);
            rating.setText(textentered4);
            Intent getImage = getIntent();
            releasedate.setText(textentered3);
            gettingImageUrl = String.valueOf(getImage.getStringExtra("image"));
            Picasso.with(this).load(gettingImageUrl)
                    .placeholder(R.drawable.progress_animation)
                    .into(iamgt);
            REVIEW_WEBSITE = "https://api.themoviedb.org/3/movie/" + currentMovie.getId() + "/reviews?api_key=b549ea5986562cb818e16877886899df&language=en-US"; // please enter your key

            TRAILER_WEBSITE = "https://api.themoviedb.org/3/movie/" + currentMovie.getId() + "/videos?api_key=b549ea5986562cb818e16877886899df&language=en-US"; // please enter your api key
        }
        Uri uri = BASE_CONTENT_URI.buildUpon().appendEncodedPath("movies/" + Integer.toString(currentMovie.getId())).build();
        c = getContentResolver().query(uri,null, MovieContract.MovieEntry.COLUMN_ID,null, MovieContract.MovieEntry.COLUMN_TITLE);
        QuakeRevs tasks = new QuakeRevs();
        tasks.execute(REVIEW_WEBSITE);
        Log.i("review first one ", rev);
        TrailerAsyncTask task = new TrailerAsyncTask();
        task.execute(TRAILER_WEBSITE);
        //key = MovieDetailActivity.getKey();
        Log.i("THE KEY IS ", key);
        expandableListViewT.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // gets the current movie
                Trailer currentMovie = tAdapter.getItem(position);
                Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + currentMovie.getKey()));
                Intent webIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/watch?v=" + key));
                Log.i("message", "https://www.youtube.com/watch?v=" + key);
                try {
                    startActivity(appIntent);
                } catch (ActivityNotFoundException ex) {
                    startActivity(webIntent);
                }
            }
        });
        onToggleClicked();
    }

    public void onToggleClicked() {
        if (c != null&&c.getCount() >0) {
            //set favorite button to delete
            isFavorite = true;
            toggleButton.setImageDrawable(getResources().getDrawable(R.drawable.star));
        }

        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isFavorite) {
                    Uri uri = BASE_CONTENT_URI.buildUpon().appendEncodedPath("movies/" + Integer.toString(currentMovie.getId())).build();
                    getContentResolver().delete(uri, null, null);
                    Log.i("uri", uri.toString());
                    Toast.makeText(getBaseContext(), "movie is deleted ", Toast.LENGTH_SHORT).show();
                    isFavorite=false;
                    // handle toggle on
                }
                else {

                    ContentValues contentValues = new ContentValues();
                    // Put the task description and selected mPriority into the ContentValues
                    contentValues.put(MovieContract.MovieEntry.COLUMN_TITLE, currentMovie.gettitle());
                    contentValues.put(MovieContract.MovieEntry.COLUMN_DATE, currentMovie.getreleasedate());
                    contentValues.put(MovieContract.MovieEntry.COLUMN_OVERVIEW, currentMovie.getOverview());
                    // contentValues.put(MovieContract.MovieEntry.COLUMN_IMAGE, currentMovie.getPoster2());
                    contentValues.put(MovieContract.MovieEntry.COLUMN_RATE, currentMovie.getvoteaverge());
                    contentValues.put(MovieContract.MovieEntry.COLUMN_ID, currentMovie.getId());
                    // Insert the content values via a ContentResolver
                    Uri uri = getContentResolver().insert(MovieContract.MovieEntry.CONTENT_URI, contentValues);
                    if (uri != null) {
                        Toast.makeText(getBaseContext(), "movie is added ", Toast.LENGTH_SHORT).show();
                        isFavorite = true;

                    }
                }
            }
        });

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        // When the home button is pressed, take the user back to the MocieActivity
        if (id == android.R.id.home) {
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }

    class TrailerAsyncTask extends AsyncTask<String, Void, ArrayList<Trailer>> {

        private ProgressDialog progressDialog;

        @Override
        protected ArrayList<Trailer> doInBackground(String... strings) {
            ArrayList<Trailer> result = null;
            if (Looper.myLooper() == null)
                Looper.prepare();

            try {
                result = QueryTrailer.fetchTrailerData(TRAILER_WEBSITE);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<Trailer> trailer) {
            super.onPostExecute(trailer);
            if (trailer != null && !trailer.isEmpty()) {

                for (Trailer review : trailer) {
                    Log.i("DATA: ", review.getKey());
                }


                tAdapter.addAll(trailer);
            }

        }
    }


    class QuakeRevs extends AsyncTask<String, Void, ArrayList<Review>> {

        private ProgressDialog progressDialog;

        @Override
        protected ArrayList<Review> doInBackground(String... strings) {
            ArrayList<Review> result = null;
            if (Looper.myLooper() == null)
                Looper.prepare();

            try {
                result = QueryReview.fetchReviewData(REVIEW_WEBSITE);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(ArrayList<Review> data) {
            super.onPostExecute(data);

            if (data != null && !data.isEmpty()) {

                for (Review review : data) {
                    Log.i("DATA: ", review.getReview());
                    mAdapter.addAll(data);
                }
            }
        }

    }

}
