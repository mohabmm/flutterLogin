package com.nocom.movie2;

/**
 * Created by Moha on 9/30/2017.
 */

public class Trailer {
    private String key ;

    public Trailer (String nkey)
    {
        key=nkey;
    }

    public String getKey() {
        return key;
    }
}
