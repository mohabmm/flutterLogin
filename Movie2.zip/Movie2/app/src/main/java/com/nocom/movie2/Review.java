package com.nocom.movie2;

/**
 * Created by Moha on 9/29/2017.
 */

public class Review {

    private String review ;

    public Review (String nReview){

        review=nReview;

    }

    public String getReview() {
        return review;
    }
}
