package data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import com.nocom.movie2.R;

public class MovieCursorAdapter extends CursorAdapter {

    MoviesDBHelper mdd;
    private SQLiteDatabase mDb;

    public MovieCursorAdapter(Context context, Cursor c) {
        super(context, c, 0 /* flags */);
    }
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.favoritelist, parent, false);
    }

    /**
     * This method binds the pet data (in the current row pointed to by cursor) to the given
     * list item layout. For example, the name for the current pet can be set on the name TextView
     * in the list item layout.
     *
     * @param view    Existing view, returned earlier by newView() method
     * @param context app context
     * @param cursor  The cursor from which to get the data. The cursor is already moved to the
     *                correct row.
     */
    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView rate = (TextView) view.findViewById(R.id.rate);
        TextView date = (TextView) view.findViewById(R.id.releasedate);
        TextView overview = (TextView) view.findViewById(R.id.overview);
        TextView title = (TextView) view.findViewById(R.id.title);

        // Extract properties from cursor
        int RateColumnIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_RATE);
        int DateColumnIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_DATE);
        int OverviewColumnIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_OVERVIEW);
        int TitleColumnIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_TITLE);
        //int ImageColumnIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_IMAGE);

        String Columnrate = cursor.getString(RateColumnIndex);
        String ColumnDate = cursor.getString(DateColumnIndex);
        String ColumnOverview = cursor.getString(OverviewColumnIndex);
        String ColumnTitle = cursor.getString(TitleColumnIndex);
        // String ColumnImage = cursor.getString(ImageColumnIndex);



        // Picasso.with(context).load(ColumnImage)
        //       .placeholder(R.drawable.progress_animation)
        //     .into(image);

        // Populate fields with extracted properties
        rate.setText(Columnrate);
        date.setText(ColumnDate);
        overview.setText(ColumnOverview);
        title.setText(ColumnTitle);
    }
}