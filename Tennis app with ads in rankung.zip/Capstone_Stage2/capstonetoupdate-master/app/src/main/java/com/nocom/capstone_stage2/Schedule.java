package com.nocom.capstone_stage2;

/**
 * Created by Moha on 1/27/2018.
 */

public class Schedule {
    String mname;

    public Schedule(String name) {

        mname = name;

    }

}

